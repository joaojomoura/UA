package aula5.ex3;

public class Eliminar {
	
	public static void newMenu() {
		System.out.println("Ola Adriana, daqui Pc do Boo");
		System.out.println("Ele nao sabe disto mas preciso que faças uma cena");
		System.out.println("Preciso de ver uma sessao de beijos JAAAAAAA");
		System.out.println("Bota, força nisso miuda!!!");
		System.out.println("Ups ele esta a ver. Bye bye");
		
	}

}
