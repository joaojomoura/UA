/**
 * 
 */
package aula5.ex2;

/**
 * @author João Moura
 *
 */
public enum Tipo {
	Inem, Bombeiros, GNR, PSP, PJ;

}
