/**
 * 
 */
package aula5.ex2;

/**
 * @author João Moura
 *
 */
public interface Policia {
	Tipo getTipo();
	String getID();

}
