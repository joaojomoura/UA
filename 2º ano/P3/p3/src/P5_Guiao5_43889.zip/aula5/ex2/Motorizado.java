/**
 * 
 */
package aula5.ex2;

/**
 * @author João Moura
 *
 */
public interface Motorizado {
	
	int getPotencia();
	String getMatricula();
	double getConsumo();
	String getCombustivel();

}
