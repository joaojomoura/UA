/**
 * 
 */
package aula6.ex1;

/**
 * @author João Moura
 *
 */
public interface Vegetariano {

}
