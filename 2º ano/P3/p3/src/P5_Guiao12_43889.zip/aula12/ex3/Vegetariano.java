/**
 * 
 */
package aula12.ex3;

/**
 * @author João Moura
 *
 */
public interface Vegetariano {

}
