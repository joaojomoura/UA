/**
 * 
 */
package aulo8.ex3;

import java.io.IOException;

/**
 * @author João Moura
 *
 */
public class QQSM {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		@SuppressWarnings("unused")
		Milionario jogo = new Milionario("questions.txt");

	}

}
