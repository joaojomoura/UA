package aula13.ex2.plugins;

import aula13.ex2.IPlugin;

public class Plug1 implements IPlugin {
	

	@Override
	public void fazQualQuerCoisa() {
		System.out.println("plug1");
		
	}
}
