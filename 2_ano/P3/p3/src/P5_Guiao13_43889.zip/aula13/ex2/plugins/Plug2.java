package aula13.ex2.plugins;

import aula13.ex2.IPlugin;

public class Plug2 implements IPlugin {
	

	@Override
	public void fazQualQuerCoisa() {
		// TODO Auto-generated method stub
		System.out.println("Plug3, lol");
		
	}
}
