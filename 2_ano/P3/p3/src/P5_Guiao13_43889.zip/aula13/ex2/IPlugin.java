/**
 * 
 */
package aula13.ex2;

/**
 * @author João Moura
 *
 */
public interface IPlugin {
	public void fazQualQuerCoisa ();

}
