void send2displays(unsigned char value)       
{          
    static const char display7Scodes[] = {0x3F, 0x06, 0x5b};          

    static char displayFlag = 0;
    unsigned char digit_low = value & 0x0F;          
    unsigned char digit_high = value >> 4; 

    if(displayFlag == 0)
    {
        LATDbits.LATD6 = 1; // display high active          
        LATDbits.LATD5 = 0; // display low inactive 
        LATB = (LATB & 0x00FF) | ((short)display7Scodes[digit_low] << 8);
    }
    else
    {
        LATDbits.LATD6 = 0; // display high active          
        LATDbits.LATD5 = 1; // display low inactive 
        LATB = (LATB & 0x00FF) | ((short)display7Scodes[digit_high] << 8);
    }

    displayFlag = displayFlag ^ 0x01;
}
